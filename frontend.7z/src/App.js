import TelaCadastroCliente from "./telasCadastro/TelaCadastroCliente";

function App() {
  return (
    <div className="App">
      <TelaCadastroCliente />
    </div>
  );
}

export default App;
